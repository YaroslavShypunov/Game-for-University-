function Start(){
    $('#menu').slideDown('slow');
        $('#time').css('display','none');
}
$(function () {
    setTimeout(Start,1000);
    
    $('#lang').on('click',function(){
        if($('.language').is(':hidden')){
       $('.language').css('display','block');
        
      $('.language').eq(0).animate({
          opacity:1.0,
          left:'-250px'
      },50);
     $('.language').eq(1).animate({
          opacity:1.0,
          left:'-250px'
      },55);
        $('.language').eq(2).animate({
            opacity:1.0,
          left:'-250px'
      },60);
        $('.language').eq(3).animate({
            opacity:1.0,
          left:'-250px'
      },65);
  
    }else{
                  $('.language').animate({
                      opacity: 0.0,
                    left: '0px'
               },60);
                  $('.language').css('display',"none");
                  }
          });
       
    
    $('#ManWoman').on('click',function(){
       if($('.sex').is(':hidden')){
           $('.sex').css('display','block');
           $('.sex').eq(0).animate({
               opacity:1.0,
               left:'-450px'
           },50);
           $('.sex').eq(1).animate({
               opacity:1.0,
               left:'-250px'
           },50);
       } else{
           $('.sex').animate({
               opacity:0.0,
               left:'0px'
           },70);
           $('.sex').css('display','none');
       }
    });


/*-----------------------------_NewGame_-----------------------------*/


//   $('#start').ready(function(){
   //    setTimeout(startGame,1000);
         
 //});

});

 //   function startGame(){
   //           $('#menu').slideUp('slow');
     //  $('#menu').css('display','none');
    //}